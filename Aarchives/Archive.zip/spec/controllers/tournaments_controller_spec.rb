require 'rails_helper'

RSpec.describe TournamentsController, type: :controller do

end
